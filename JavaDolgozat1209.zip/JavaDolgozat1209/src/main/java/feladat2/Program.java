package feladat2;

public class Program {
    public static void main(String[] args) {
        LogikaiJatek j1 = new LogikaiJatek(3);
        LogikaiJatek j2 = new LogikaiJatek(10);
        //System.out.println(j1.toString());
    }
}

//net bedugva